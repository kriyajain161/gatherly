export default { logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519664016579252/yBOBgUDZocVHnPZx.svg" };
